#!/usr/bin/perl
use strict;
use Data::Dumper;
use FindBin '$Bin';

die "---------------------------------------------------------------------------------------
                                     Find peptides by Indel information 

Description

     To create a list of tumor-specific peptides (8-13) with the in-house script.

Contact

     liugeng liugeng\@genomics.cn
     lidongli lidongli\@genomics.cn

usage

     perl $0 <muts> <protein> <cds> <output dir> <min len> <max len>

sample

     perl ./find_peptides_Indel.pl test/Mutation.list data/RefSeq.protein.fasta data/RefSeq.CDS.fasta ./test 8 13

---------------------------------------------------------------------------------------\n" if(@ARGV != 6);
my ($muts, $protein, $cds, $dir, $min_len, $max_len) = @ARGV;
system("mkdir -p $dir/peptide") unless (-e "$dir/peptide");
for my $len ($min_len..$max_len)
{
	open(OUT, ">$dir/peptide/MT.Indel.$len.fa") || die $!;
	close OUT;
}

my %CODE = (
	"standard" =>
	{
		'GCA' => 'A', 'GCC' => 'A', 'GCG' => 'A', 'GCT' => 'A',                               # Alanine
		'TGC' => 'C', 'TGT' => 'C',                                                           # Cysteine
		'GAC' => 'D', 'GAT' => 'D',                                                           # Aspartic Acid
		'GAA' => 'E', 'GAG' => 'E',                                                           # Glutamic Acid
		'TTC' => 'F', 'TTT' => 'F',                                                           # Phenylalanine
		'GGA' => 'G', 'GGC' => 'G', 'GGG' => 'G', 'GGT' => 'G',                               # Glycine
		'CAC' => 'H', 'CAT' => 'H',                                                           # Histidine
		'ATA' => 'I', 'ATC' => 'I', 'ATT' => 'I',                                             # Isoleucine
		'AAA' => 'K', 'AAG' => 'K',                                                           # Lysine
		'CTA' => 'L', 'CTC' => 'L', 'CTG' => 'L', 'CTT' => 'L', 'TTA' => 'L', 'TTG' => 'L',   # Leucine
		'ATG' => 'M',                                                                         # Methionine
		'AAC' => 'N', 'AAT' => 'N',                                                           # Asparagine
		'CCA' => 'P', 'CCC' => 'P', 'CCG' => 'P', 'CCT' => 'P',                               # Proline
		'CAA' => 'Q', 'CAG' => 'Q',                                                           # Glutamine
		'CGA' => 'R', 'CGC' => 'R', 'CGG' => 'R', 'CGT' => 'R', 'AGA' => 'R', 'AGG' => 'R',   # Arginine
		'TCA' => 'S', 'TCC' => 'S', 'TCG' => 'S', 'TCT' => 'S', 'AGC' => 'S', 'AGT' => 'S',   # Serine
		'ACA' => 'T', 'ACC' => 'T', 'ACG' => 'T', 'ACT' => 'T',                               # Threonine
		'GTA' => 'V', 'GTC' => 'V', 'GTG' => 'V', 'GTT' => 'V',                               # Valine
		'TGG' => 'W',                                                                         # Tryptophan
		'TAC' => 'Y', 'TAT' => 'Y',                                                           # Tyrosine
		'TAA' => 'X', 'TAG' => 'X', 'TGA' => 'X'                                              # Stop
		}
	);

my %mut;
open(FH, $muts) || die $!;
while(<FH>)
{
	chomp;
	my @tmp = split /\t/;
	next if(/^#/);
	next if($tmp[4] ne "Indel");
	push @{$mut{$tmp[3]}{$tmp[6]}{site}}, $tmp[7];
	push @{$mut{$tmp[3]}{$tmp[6]}{type}}, $tmp[5];
}
close FH;

local $/ = "\n>";
my %pro;
open(FH, $protein) || die $!;
while(<FH>)
{
	chomp;
	s/^>//;
	my ($tag, $seq) = split(/\n/, $_, 2);
	$seq =~ s/\n//g;
	$pro{$tag} = $seq;
}
close FH;

my %output; 
open(FH, $cds) || die $!;
while(<FH>)
{
	chomp;
	s/^>//;
	my ($tag, $seq) = split(/\n/, $_, 2);
	my ($id) = $tag =~ /(NM_[0-9]+)/;
	$seq =~ s/\n//g;
	for my $name (keys %mut)
	{
		if(exists $mut{$name}{$id}{site})
		{
			my @sites = @{$mut{$name}{$id}{site}};
			foreach my $i(0..$#sites)
			{
				my $site = $mut{$name}{$id}{site}[$i];
				my $indel_type = $mut{$name}{$id}{type}[$i];
				print STDERR "$indel_type\t$site\n";
				my ($start, $end);
				my @seqs;
				if($site =~ /del/)
				{
					if($site =~ /_/)
					{
						($start) = $site =~ /c\.([0-9]+)_/;
						($end) = $site =~ /c\.[0-9]+_([0-9]+)del/;
					}
					else
					{
						($start) = $site =~ /c\.([0-9]+)del/;
						$end = $start;
					}
					@seqs = split //, $seq;
					splice(@seqs, $start - 1, $end - $start + 1);
				}

				my %out;
				my $ins_len = 0;
				if($site =~ /ins/ || $site =~ /dup/) 
				{
					if($site =~ /_/)
					{
						($start) = $site =~ /c\.([0-9]+)_/;
						($end) = $site =~ /c\.[0-9]+_([0-9]+)[ins|dup]/; 
					}
					else
					{
						($start) = $site =~ /c\.([0-9]+)[ins|dup]/; 
						$end = $start;
					}
					my ($ins) = $site =~ /[dup|ins]([ACGT]+)/; 
					my @ins = split //, $ins;
					$ins_len = scalar @ins;
					@seqs = split //, $seq;
					splice(@seqs, $start,0,@ins); 
				}
			
		              	if ($indel_type =~ /^frameshift/){ 
					if ($site =~ /del/){
						&frameshift($id, $site, $start-1, @seqs); 
					}elsif ($site =~ /[ins|dup]/){
						&frameshift($id, $site, $start, @seqs); 
					}
				}elsif ($indel_type =~ /^nonframeshift/){
					if ($site =~ /del/){
						&nonframeshift($id, $site,$start-1,$start-1,@seqs); 
					}elsif ($site =~ /[ins|dup]/){
						&nonframeshift($id, $site,$start,$start+$ins_len-1,@seqs); 
					}
				}
			}
		}
	}
}
close FH;
local $/ ="\n>";

for my $len(sort {$a <=> $b} keys %output){
	open OUT, ">$dir/peptide/MT.Indel.$len.fa" or die "$!";
	for my $this_peptide(sort keys %{$output{$len}}){
		my @names = sort keys %{$output{$len}{$this_peptide}};
		my $this_name = join(";",@names);
		print OUT ">$this_name\n$this_peptide\n";
	}
	close OUT;
}
close FASTA;
close INFO;

########################################## Sub ##########################################
sub nonframeshift{
	my ($name,$site,$this_start,$this_end,@seqs) = @_;
	my $protein = "";
	my $mut_start_pos = int(($this_start)/3)+1;
	my $mut_end_pos = int(($this_end)/3)+1;
	my $mut_len = $mut_end_pos - $mut_start_pos + 1;
	for (my $i=0; $i<=$#seqs-3; $i+=3)
        {
                my $temp = $seqs[$i].$seqs[$i+1].$seqs[$i+2];
		my $aa = $CODE{'standard'}{$temp}; # translate terminate when reach stop codon
                last if ($aa eq 'X'); # translate terminate when reach stop codon
                $protein .= $aa; # translate terminate when reach stop codon
        }
	for my $len($min_len..$max_len){
		my $this_protein = substr($protein,$mut_start_pos-$len,$mut_len+2*$len-2);
		next if (length($this_protein)-$len < 0);
		for my $i (0..length($this_protein)-$len){
			my $sub = substr($this_protein, $i, $len);
			my $tag = 0;
			for my $id (%pro){
				if($pro{$id} =~ /$sub/){
					$tag = 1;
					last;
				}
			}

			$output{$len}{$sub}{"$name-$site-$len-$i"}++ if($tag == 0); ## remove duplicate peptides
		}
	}
}
		
sub frameshift()
{
	my ($name, $site, $this_start, @seqs) = @_;
	my $protein = "";
	for (my $i=0; $i<=$#seqs-3; $i+=3)
	{
		my $temp = $seqs[$i].$seqs[$i+1].$seqs[$i+2];

		my $aa = $CODE{'standard'}{$temp}; # translate terminate when reach stop codon
		last if ($aa eq 'X'); # translate terminate when reach stop codon
		$protein .= $aa; # translate terminate when reach stop codon
	}
	my $mut_aa_pos = int(($this_start)/3)+1;
	for my $len ($min_len..$max_len)
	{
		my $this_protein = substr($protein,$mut_aa_pos-$len-1);
		next if (length($this_protein)-$len < 0);
		for my $i (0..length($this_protein)-$len)
		{
			my $sub = substr($this_protein, $i, $len);
			my $tag = 0;
			for my $id (%pro)
			{
				if($pro{$id} =~ /$sub/)
				{
					$tag = 1;
					last;
				}
			}
 
			$output{$len}{$sub}{"$name-$site-$len-$i"}++ if($tag == 0); ## remove duplicate peptides
						
		}
	}
}
