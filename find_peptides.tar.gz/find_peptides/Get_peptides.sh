perl ./find_peptides_SNV.pl test/Mutation.list data/human.protein.gpff data/RefSeq.protein.fasta ./test 8 13
perl ./find_peptides_Indel.pl test/Mutation.list data/RefSeq.protein.fasta data/RefSeq.CDS.fasta ./test 8 13
