perl ./find_peptides_SNV.pl test/Mutation.list data/RefSeq.protein.fasta ./test 9 9
perl ./find_peptides_Indel.pl test/Mutation.list data/RefSeq.protein.fasta data/RefSeq.CDS.fasta ./test 9 9
