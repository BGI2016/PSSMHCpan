#!usr/bin/perl
use strict;
use lib '~/myscripts/build/Storable-2.51/blib/lib';
use Storable;
use FindBin '$Bin';

################# COMAND LINE INPUT ##############
die "---------------------------------------------------------------------------------------
                                    Find peptides by SNV information

Description

  To create a list of tumor-specific peptides (8-13) with the in-house script.

Contact

  liugeng liugeng\@genomics.cn
  lidongli lidongli\@genomics.cn

usage

    perl $0 <mut_file> <protein> <output directory> <min len> <max len>
    

sample

    perl ./find_peptides_SNV.pl test/Mutation.list data/RefSeq.protein.fasta ./test 9 9


---------------------------------------------------------------------------------------\n" if @ARGV !=5;
my($muts, $pro_fasta, $dir, $min_len, $max_len) = @ARGV;
system("mkdir -p $dir/peptide") unless (-e "$dir/peptide");
################# BUILD PEPTIDE DATA BASE FOR FILTER ############

my$filter_pro_data;

for my $pep_len ($min_len..$max_len)
{
	open MT,"> $dir/peptide/MT.SNV.$pep_len.fa" or die $!;
	open WT,"> $dir/peptide/WT.SNV.$pep_len.fa" or die $!;
	close MT;
	close WT;
}

################# INPUT FILES #################

######### REMOVE SYNONYMOUS AND MATCH GENE WITH MUTATION SITES ############
#Chromosome\\t\\tStart\\tEnd\tGene\\tType\\tFunction\\tNM_code\\tBase_alter\\tAA_alter
my(%NM2gene,%NM2site,%NM2NP,%NP2NM,%NP2site);
open RAW,"< $muts" or die $!;
while(<RAW>){
	chomp $_;
	next if(/^#/);
	my@temp= split /\t/, $_;
	next if($temp[4] ne "SNV");
	$NM2gene{$temp[6]}=$temp[3];
	push @{$NM2site{$temp[6]}}, $temp[8];
}
close RAW;
################ FIND NP CODE OF NM ################
open GFP,"< $Bin/data/NP2NM.list" or die $!;
while(<GFP>){
      chomp $_;
      my @arr=split /\s+/,$_;
      my $NP=$arr[0];
      my $NM=$arr[1];
	$NM2NP{$NM}=$NP;
	$NP2NM{$NP}=$NM;
}

foreach(keys%NM2site){
	if(exists $NM2NP{$_}){
		@{$NP2site{$NM2NP{$_}}}=@{$NM2site{$_}};
	}
}
############### FIND PROTEIN SEQUENCE FROM FASTA ##############
my %protein;
local $/ = "\n>";
open FASTA,"< $pro_fasta" or die $!;
while(<FASTA>)
{
	chomp;
	s/^>//;
	my ($id, $seq) = split (/\n/, $_, 2);
	$seq =~ s/\n//g;
	$protein{$id} = $seq;
}
close FASTA;
local $/ = "\n";

my$aa_list="GAVLIPFYWSTCMNQDEKRH";

foreach(keys%NP2site){
	my$gene_name=$NM2gene{$NP2NM{$_}};
        my $NM_name=$NP2NM{$_};
	my$pro_seq=$protein{$_};
	my@site_info=@{$NP2site{$_}};
	foreach my$pep_len($min_len..$max_len) {
		open MT,">> $dir/peptide/MT.SNV.$pep_len.fa" or die $!; # result 
		open WT,">> $dir/peptide/WT.SNV.$pep_len.fa" or die $!; # result
                 foreach (@site_info){
		
			my$mut_pos=$1 if $_=~ /p\.\w(\d+)\w/;
			my$mut_aa=$1 if $_=~ /p\.\w\d+(\w)/;
			my$aa=$1 if $_=~ /p\.(\w)\d+\w/;
			my@mut_seqs=mut_peptide($pro_seq,$mut_pos,$mut_aa,$pep_len, $_);
		      
                        my $pep_info=$NM_name."-".$_."-";
			for (my$i=0;$i<@mut_seqs;$i++){
				next if($mut_seqs[$i] eq "NA");
				my$temp;
				if ($mut_pos<$pep_len){$temp=$mut_pos}else{$temp=$pep_len}
				$temp=$temp-$i;
				my@sub_mut_seqs=split //,$mut_seqs[$i];
				my$valid_aa=0;
				for my$a(@sub_mut_seqs){$valid_aa++ if $aa_list=~ /$a/}
				$mut_seqs[$i] =~ s/U/X/g;
				my $wt = $mut_seqs[$i];
				
				if($mut_aa eq substr($mut_seqs[$i], $temp-1, 1))
				{
					substr($wt, $temp-1, 1) = $aa;
				}
				else
				{
					die;
				}
                                print MT  ">".$pep_info.length($mut_seqs[$i])."-".$temp."\n$mut_seqs[$i]\n";
			        print WT  ">".$pep_info.length($mut_seqs[$i])."-".$temp."\n$wt\n";
			}
		}
		close MT;
		close WT;
	}
}


###############  MY SUBS  #########################

sub mut_peptide{
	my$peptide=shift;
	my$pos=shift;
	my$aa=shift;
	my$length=shift;
	my$change=shift;
	my@frag_pep;
	my@temp=split //,$peptide;
	$temp[$pos-1]=$aa;
	my$result=join("",@temp);
	my $pep_lth = length $peptide;
        my $start = $pos-$length;
        my $end = $pos-1;
        $start = 0 if ($start<0);
        my $end_last = $pep_lth - $length;
        $end = $end_last if ($end > $end_last);
        for (my $i=$start; $i<=$end;$i++){
                my $str = substr($result,$i,$length);
		my $tag = 0;
		for my $id (keys %protein)
		{
			if($protein{$id} =~ /$str/)
			{
				$tag = 1;
				last;
			}
		}
                if($tag == 0)
		{
			push @frag_pep,$str;
		}
		else
		{
			push @frag_pep, "NA";
		}
        }
	return @frag_pep;
}
