perl ./PSSMHCpan-1.0.pl test/test.fa 9 HLA-A0201 database/PSSM/pssm_file.list
perl ./PSSMHCpan-1.0.pl test/test.fa 9 HLA-A0102 database/PSSM/pssm_file.list
